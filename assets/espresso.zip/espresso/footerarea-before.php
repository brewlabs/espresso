<?php return;
/**
* 	WARNING: This file is part of the Espresso framework. DO NOT edit
* 	this file under any circumstances. Please do all modifications
* 	in the form of a child theme. 
*
*	create footer-before.php in your child theme
*
*	This file is loaded inside the footer just before footer-content.php
*/
?>