<?php return;
/**
* 	WARNING: This file is part of the Espresso framework. DO NOT edit
* 	this file under any circumstances. Please do all modifications
* 	in the form of a child theme. 
*
*	create theme-before-content.php in your child theme
*	
*	this file is loaded between end of the header and the start of the content
*/
?>