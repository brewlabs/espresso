<?php get_template_part('footer','widgets'); ?>
<?php get_template_part('footer','widgets-after'); ?>
<div id="footer-container" <?php espresso_footer_container();?>>
	<div id="footer-wrap-outer" class="footer_wrap_outer clearfix">
		<div id="footer-wrap" class="footer_wrap clearfix">
			<?php get_template_part('footer','content'); ?>
		</div>
	</div>
</div>
