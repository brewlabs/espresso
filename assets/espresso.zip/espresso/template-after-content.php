<?php return;
/**
* 	WARNING: This file is part of the Espresso framework. DO NOT edit
* 	this file under any circumstances. Please do all modifications
* 	in the form of a child theme. 
*
*	create theme-after-content.php in your child theme
*	
*	this file is loaded between end of the content and the start of the footer
*/
?>