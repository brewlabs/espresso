#  Espresso Theme Framework

## Summary:

Theme Framework for WordPress based off get_template_part setup.

## Info:

All theme assets are stored in the hopper folder. You should not need to edit this theme it is designed to be a Parent theme with and every piece can be overwritten.