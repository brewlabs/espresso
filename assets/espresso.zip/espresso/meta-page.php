<footer class="entry-meta">
  	<?php edit_post_link('Edit','',' this page or post.'); ?>
</footer>